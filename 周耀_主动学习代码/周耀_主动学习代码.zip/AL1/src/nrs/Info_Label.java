package nrs;

import java.util.ArrayList;

import weka.core.Instance;
import weka.core.Instances;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.Remove;

//�ޱ�ǩ������ѵ�����е���Ϣ��
public class Info_Label {
	private Instances train;// ѵ����
	private Instance instance;// �ޱ�ǩ����
	private ArrayList<Double> distances = new ArrayList<>();
	public Info_Label(Instances train, Instance instance) throws Exception {
		super();
		// ȥ��class
		String options[] = new String[2];
		options[0] = "-R";
		options[1] = "last";
		Remove rm = new Remove();
		rm.setOptions(options);
		rm.setInputFormat(train);
		this.train = Filter.useFilter(train, rm);
		this.instance = instance;
	}

	public double info_label(double w) {
		calc_distance();
		double radius=getRadius(w);
		double info=0;
		for(int i=0;i<train.numInstances();i++)
		{
			if (distances.get(i)<radius) {
				info+=Informative.computeSim(instance, train.instance(i));
			}
		}
		return info;
	}

	// ���������������ѵ�����ľ���
	public void calc_distance() {
		Neighbourhood nb = new Neighbourhood();
		for (int i = 0; i < train.numInstances(); i++) {
			distances.add(nb.CalDistance(train.instance(i), instance));
		}
	}

	// �����������ѵ�����е�����뾶
	public double getRadius(double w) {
		double r = 0;
		double max = Double.MIN_VALUE;
		double min = Double.MAX_VALUE;
		for (int i = 0; i < train.numInstances(); i++) {
			double tmpdis = distances.get(i);
			if (tmpdis > max) {
				max = tmpdis;
			}
			if (tmpdis < min) {
				min = tmpdis;
			}
		}
		r = min + w * (max - min);
		return r;
	}
}
