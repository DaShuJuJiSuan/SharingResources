package nrs;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Random;

import util.Util;
import weka.core.Instances;

public class Active9 extends Active {
	private NRS nrs;

	public Instances getData() {
		return data;
	}

	public Active9(Instances data) throws Exception {
		super(data);
		data.setClassIndex(data.numAttributes() - 1);
		nrs = new NRS(data, unlabel_index);
	}

	// ίԱ��ͶƱ����QBC
	public ArrayList<Integer> qbc(int modelNum, int num) throws Exception {
		ArrayList<Score> list = new ArrayList<>(unlabel.size());
		QBC qbc = new QBC(data, train, unlabel, modelNum, data.numAttributes() - 1);
		for (int index : unlabel) {
			Score score = new Score(index, qbc.getScore(index));
			list.add(score);
		}
		ArrayList<Integer> select = new ArrayList<>();
		int index = 0;
		while (num > 0) {
			try {
				select.add(list.get(index++).id);
			} catch (Exception e) {
			}
			num--;
		}
		return select;
	}

	// �ֲڼ�����ѧϰ����
	public ArrayList<Integer> learning(double w, int p, int num) {
		ArrayList<Score> list = new ArrayList<>(unlabel.size());
		for (int index : unlabel) {
			Score score = new Score(index, nrs.Info(index, train, unlabel, w, p));
			list.add(score);
		}
		list.sort(new Comparator<Score>() {
			@Override
			public int compare(Score o1, Score o2) {
				return new Double(o2.score).compareTo(new Double(o1.score));
			}
		});
		ArrayList<Integer> select = new ArrayList<>();
		int index = 0;
		while (num > 0) {
			try {
				select.add(list.get(index++).id);
			} catch (Exception e) {
			}
			num--;
		}
		return select;
	}

	// ��ȷ����ѡ�񷽷�
	public ArrayList<Integer> uncertainty(double w, int num) {
		ArrayList<Score> list = new ArrayList<>(unlabel.size());
		for (int index : unlabel) {
			Score score = new Score(index, nrs.classInfo(index, train, w));
			list.add(score);
		}
		list.sort(new Comparator<Score>() {
			@Override
			public int compare(Score o1, Score o2) {
				return new Double(o2.score).compareTo(new Double(o1.score));
			}
		});
		ArrayList<Integer> select = new ArrayList<>();
		int index = 0;
		while (num > 0) {
			try {
				select.add(list.get(index++).id);
			} catch (Exception e) {
			}
			num--;
		}
		return select;
	}

	// ������ѡ�񷽷�
	public ArrayList<Integer> generalize(double w, int num) {
		ArrayList<Score> list = new ArrayList<>(unlabel.size());
		for (int index : unlabel) {
			Score score = new Score(index, nrs.generalize(index, train, unlabel, w));
			list.add(score);
		}
		list.sort(new Comparator<Score>() {
			@Override
			public int compare(Score o1, Score o2) {
				return new Double(o2.score).compareTo(new Double(o1.score));
			}
		});
		ArrayList<Integer> select = new ArrayList<>();
		int index = 0;
		while (num > 0) {
			try {
				select.add(list.get(index++).id);
			} catch (Exception e) {
			}
			num--;
		}
		return select;
	}

	// ���ѡ��
	public ArrayList<Integer> rand(int n) {
		ArrayList<Integer> first = new ArrayList<>();
		Random random = new Random();
		while (first.size() < n) {
			try {
				int r = random.nextInt(unlabel.size());
				if (!first.contains(r)) {
					first.add(unlabel.get(r));
				}
			} catch (Exception e) {
				return first;
			}
		}
		return first;
	}

	public static void nrs_active(String path) {
		double a[][] = new double[50][10];
		for (int k = 0; k < 10; k++) {
			Active9 active = null;
			try {
				active = new Active9(Util.getInstances(path));
			} catch (Exception e) {
			}
			int insSize = (int) (active.unlabel.size() / 50);
			for (int i = 0; i < 50; i++) {
				try {
					ArrayList<Integer> select = new ArrayList<>();
					if (i < 3) {
						select = active.rand(insSize);
					} else {
						select = active.learning(0.01, 1, insSize);
					}
					active.update(select);
					a[i][k] = active.test();
				} catch (Exception e) {
					e.printStackTrace();
				}
//				System.out.println(k);
			}
			active = null;
		}
		System.out.println("nrs_active");
		for (int i = 0; i < 50; i++) {
			for (int j = 0; j < 10; j++) {
				System.out.print(a[i][j] + ",");
			}
			System.out.println();
		}
	}

	public static void uncertain_active(String path) {
		double a[][] = new double[50][10];
		for (int k = 0; k < 10; k++) {
			Active9 active = null;
			try {
				active = new Active9(Util.getInstances(path));
			} catch (Exception e) {
			}
			int insSize = (int) (active.unlabel.size() / 50);
			for (int i = 0; i < 50; i++) {
				try {
					ArrayList<Integer> select = new ArrayList<>();
					select = active.uncertainty(0.01, insSize);
					active.update(select);
					a[i][k] = active.test();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			active = null;
		}
		System.out.println("uncertain_active");
		for (int i = 0; i < 50; i++) {
			for (int j = 0; j < 10; j++) {
				System.out.print(a[i][j] + ",");
			}
			System.out.println();
		}
	}
	
	public static void generalize_active(String path) {
		double a[][] = new double[50][10];
		for (int k = 0; k < 10; k++) {
			Active9 active = null;
			try {
				active = new Active9(Util.getInstances(path));
			} catch (Exception e) {
			}
			int insSize = (int) (active.unlabel.size() / 50);
			for (int i = 0; i < 50; i++) {
				try {
					ArrayList<Integer> select = new ArrayList<>();
					select = active.generalize(0.01, insSize);
					active.update(select);
					a[i][k] = active.test();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			active = null;
		}
		System.out.println("generalize_active");
		for (int i = 0; i < 50; i++) {
			for (int j = 0; j < 10; j++) {
				System.out.print(a[i][j] + ",");
			}
			System.out.println();
		}
	}
	
	public static void qbc_active(String path) {
		double a[][] = new double[50][10];
		for (int k = 0; k < 10; k++) {
			Active9 active = null;
			try {
				active = new Active9(Util.getInstances(path));
			} catch (Exception e) {
			}
			int insSize = (int) (active.unlabel.size() / 50);
			for (int i = 0; i < 50; i++) {
				try {
					ArrayList<Integer> select = new ArrayList<>();
					select = active.qbc(5, insSize);
					active.update(select);
					a[i][k] = active.test();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			active = null;
		}
		System.out.println("qbc_active");
		for (int i = 0; i < 50; i++) {
			for (int j = 0; j < 10; j++) {
				System.out.print(a[i][j] + ",");
			}
			System.out.println();
		}
	}
	
	public static void random_active(String path)  {
		double a[][] = new double[50][10];
		for (int k = 0; k < 10; k++) {
			Active9 active = null;
			try {
				active = new Active9(Util.getInstances(path));
			} catch (Exception e) {
			}
			int insSize = (int) (active.unlabel.size() / 50);
			for (int i = 0; i < 50; i++) {
				try {
					ArrayList<Integer> select = new ArrayList<>();
					select=active.rand(insSize);
					active.update(select);
					a[i][k] = active.test();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			active = null;
		}
		System.out.println("random_active");
		for (int i = 0; i < 50; i++) {
			for (int j = 0; j < 10; j++) {
				System.out.print(a[i][j] + ",");
			}
			System.out.println();
		}
	}
	
	public static void main(String[] args) {
//		String path="H:\\Research\\data\\digit/train235.csv";
//		String path="H:\\Research\\data/wdbc.csv";
		String path = "C:\\Users\\zx\\Desktop\\�½��ļ���\\���ݼ�\\���ݼ�arff/iris.arff";
		qbc_active(path);
		uncertain_active(path);
		generalize_active(path);
		random_active(path);
		nrs_active(path);
	}
}
