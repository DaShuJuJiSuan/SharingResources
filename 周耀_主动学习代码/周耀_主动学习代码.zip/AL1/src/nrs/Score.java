package nrs;

public class Score {
	public int id;
	public double score;
	public Score(int id, double score) {
		super();
		this.id = id;
		this.score = score;
	}
	@Override
	public String toString() {
		return "id=" + id + ", score=" + score;
	}
	
}
