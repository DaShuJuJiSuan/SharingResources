package nrs;

import java.util.ArrayList;

import util.Util;
import weka.clusterers.SimpleKMeans;
import weka.core.DistanceFunction;
import weka.core.EuclideanDistance;
import weka.core.Instance;
import weka.core.Instances;
//��������Ե�����Ĳ�ȷ����
/*
 * �������
 * 1.�����ڼ����������ĵı�Ե�����ֲ�ȷ���Ը���
 * 2.������ĳ���������ĵı�Ե���������������ĺ�Զ�����ֲ�ȷ����С
 * */
public class Clustering {
	private ArrayList<ArrayList<Double>> distributions;
	private SimpleKMeans kMeans;
	private ArrayList<Double> uncertainty=new ArrayList<>();
	public Clustering(Instances unlabel) throws Exception {
		super();
		kMeans=new SimpleKMeans();
		kMeans.setNumClusters((int)Math.sqrt(unlabel.numInstances()));
//		kMeans.setNumClusters(3);
		kMeans.buildClusterer(unlabel);
		distributions=new ArrayList<>();
		for(int i=0;i<unlabel.numInstances();i++)
		{
			ArrayList<Double> list=new ArrayList<>();
			distributions.add(list);
		}
		
		for(int i=0;i<unlabel.numInstances();i++)
		{
			double distribution[]= computedistribution(unlabel.instance(i));
			for(double d:distribution)
			{
				distributions.get(i).add(d);
			}
		}
		computeUncertainty();
	}
	
	public double[] computedistribution(Instance pre)
	{
		Instances center=kMeans.getClusterCentroids();
		double result[]=new double[center.numInstances()];
		for(int i=0;i<center.numInstances();i++)
		{
			result[i]=distance(pre, center.instance(i));
		}
		return result;
	}
	
	private double distance(Instance ins1, Instance ins2) {
		double dis = 0;
		for (int j = 0; j < ins1.numAttributes() - 1; j++) {
			if (ins1.isMissing(j) || ins2.isMissing(j)) {
				dis = dis + 1;
			} else if ((!ins1.attribute(j).isNumeric()) && (!ins2.attribute(j).isNumeric())) {
				if (ins1.value(j) != ins2.value(j)) {
					dis = dis + 1;
				}
			} else if (ins1.attribute(j).isNumeric() && ins2.attribute(j).isNumeric()) {
				double t = Math.abs(ins1.value(j) - ins2.value(j));
				dis = dis + t * t;
			}
		}
		dis = Math.sqrt(dis);
		return dis;
	}
	
	public void computeUncertainty()
	{
		for(int i=0;i<distributions.size();i++)
		{
			ArrayList<Double> distri=distributions.get(i);
			Double[] data=distri.toArray(new Double[0]);
			double a[]=new double[data.length];
			for(int j=0;j<data.length;j++)
			{
				a[j]=data[j];
			}
			uncertainty.add(Uncertainty.computeUncertainty(a));
		}
	}
	
	public ArrayList<Double> getUncertainty() {
		return Util.normalize(uncertainty);
	}

	public static void main(String[] args)throws Exception {
		String in="D:\\Program Files\\Weka-3-8\\data\\airline.arff";
		Instances data=Util.getInstances(in);
		data=Util.deleteClass(data);
		Clustering clustering=new Clustering(data);
		ArrayList<Double> list=clustering.getUncertainty();
		for(double i:list)
		{
			System.out.println(i);
		}
	}
}
