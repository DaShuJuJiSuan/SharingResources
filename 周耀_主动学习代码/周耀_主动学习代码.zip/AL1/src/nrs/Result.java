package nrs;

public class Result {
	public double org_score;
	public double act_score;
	public double ran_score;
	public Result(double org_score, double act_score, double ran_score) {
		super();
		this.org_score = org_score;
		this.act_score = act_score;
		this.ran_score = ran_score;
	}
	
}
