package nrs;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

import util.Util;
import weka.core.Instances;

//���������ڵ�����
public class Reduce {
	private Instances data;// �ޱ�ǩ����
	private ArrayList<Integer> first_list;// ѡ�е�����
	private ArrayList<Integer> result_list=new ArrayList<>();// �����������
	private Neighbourhood rp;// �����ϵ
	private ArrayList<Double> radius_list;// ����뾶

	public Reduce(Instances data, ArrayList<Integer> first_list, Neighbourhood rp,double w) {
		super();
		this.data = data;
		this.first_list = first_list;
		this.rp = rp;
		radius_list = new ArrayList<>();
		reducing(w);
	}

	public ArrayList<Integer> getResult_list() {
		return result_list;
	}

	public void reducing(double w) {
		// ��������������뾶
		for (int i = 0; i < first_list.size(); i++) {
			double radius = rp.getRadius(first_list.get(i), data, w);
			radius_list.add(radius);
		}
		// ɾ��������뾶�ڵ�����
		HashSet<Integer> deletes=new HashSet<>();
		Iterator<Integer> iterator_i = first_list.iterator();
		while (iterator_i.hasNext()) {
			int i = iterator_i.next();
			Iterator<Integer> iterator_j = first_list.iterator();
			while (iterator_j.hasNext()) {
				int j = iterator_j.next();
				if (i != j) {
					double distance = rp.getDisByIndex(i, j);
					if (distance < radius_list.get(i)) {
						deletes.add(j);
					}
				}
			}
		}
		iterator_i = first_list.iterator();
		while(iterator_i.hasNext())
		{
			int i = iterator_i.next();
			if (deletes.contains(i)) {
				iterator_i.remove();
			}
		}
		
		result_list = first_list;
	}

	public static void main(String[] args) throws Exception {
		Neighbourhood rp = new Neighbourhood();
		String in = "E:\\Program Files\\Weka-3-7\\data\\diabetes.arff";
		Instances data = Util.getInstances(in);
		Instances ins = Util.deleteClass(data);
		ArrayList<Integer> first_list = new ArrayList<>();
		for (int i = 0; i < ins.numInstances(); i++) {
			first_list.add(i);
		}
		System.out.println(first_list.size());
		rp.getDisMatrix(ins);
		Reduce reduce = new Reduce(ins, first_list, rp,0.0005);
		System.out.println(reduce.getResult_list().size());
	}

}
