package util;

public class Test {
	public void testA(){
		if(testB("true")){
			System.out.println("true");
		}else {
			System.out.println("not true");
		}
	}
	public Boolean testB(String s){
		return Boolean.valueOf(s);
	}
}
