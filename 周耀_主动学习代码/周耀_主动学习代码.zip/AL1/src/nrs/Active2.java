package nrs;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Random;

import util.Util;
import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.trees.J48;
import weka.core.Instances;

/*
 * ���ޱ�ǩ������������Ϣ���� info_u
 * ���б�ǩ������������Ϣ���� info_l
 * �������Ĳ�ȷ���� Uncertainty Խ��Խ��ȷ��
 */

//rank(log(info_u/info_l)+Uncertainty)
public class Active2 {
	private Instances train;
	private Instances test;
	private Instances unlabel;
	private Instances org_unlabel;
	ArrayList<Integer> select_id = new ArrayList<>();
	public static ArrayList<String> res = new ArrayList<>();
	public static ArrayList<Double> distances=new ArrayList<>();
	
	// ����������w1:0.1 ,w2:0.9
	public Active2(Instances data, double w1, double w2) throws Exception {
		super();
//		data.randomize(new Random()); // ����
		train = new Instances(data);
		test = new Instances(data);
		unlabel = new Instances(data);
		org_unlabel = new Instances(data);
		train.delete();
		test.delete();
		unlabel.delete();
		org_unlabel.delete();
		int index_train = (int) (data.numInstances() * w1);
		int unlabel_index = (int) (data.numInstances() * w2);
		for (int i = 0; i < index_train; i++) {
			train.add(data.instance(i));
		}
		for (int i = index_train; i < unlabel_index; i++) {
			unlabel.add(data.instance(i));
			org_unlabel.add(data.instance(i));
		}
		for (int i = unlabel_index; i < data.numInstances(); i++) {
			test.add(data.instance(i));
		}
		unlabel = Util.deleteClass(unlabel);
	}

	// ����ѧϰ���̣�nΪÿ����ѡ����������
	// bound���ѡ��ı߽�
	// w2Ϊ�ޱ�ǩ����������뾶��ϵ��
	// w3Ϊ�ޱ�ǩ������ѵ�����е�����뾶ϵ��
	public void activelearning(int n, int bound, double w2, double w3) throws Exception {
		// Uncertainty uncertainty = new Uncertainty(train, test, org_unlabel);
		// ArrayList<Double> sup_uncertainty =
		// uncertainty.getLabelUncertainty(w1);
		SVMer svm = new SVMer(train, org_unlabel);
		ArrayList<Double> sup_uncertainty = distances;

		Informative informative = new Informative(unlabel, w2);
		ArrayList<Double> info_u = informative.getInfo();
		ArrayList<Double> info_l = getInfo_l(train, unlabel, w3);
		ArrayList<Score> score_list = new ArrayList<>();
		for (int i = 0; i < info_u.size(); i++) {
			double sco = (info_u.get(i) / info_l.get(i) * (1 / (0.01 + sup_uncertainty.get(i))));
//			double sco=info_u.get(i)-info_l.get(i)-1/sup_uncertainty.get(i)*sup_uncertainty.get(i);
//			sco=2*(sco1+sco)/(sco1*sco);
//			double sco = (info_u.get(i) / info_l.get(i) * (1 / (sup_uncertainty.get(i)*sup_uncertainty.get(i))));
			Score score = new Score(i, sco);
			score_list.add(score);
		}
		score_list.sort(new Comparator<Score>() {
			@Override
			public int compare(Score o1, Score o2) {
				return new Double(o2.score).compareTo(new Double(o1.score));
			}
		});
		
		
		ArrayList<Integer> first = new ArrayList<>();
		Random random=new Random();
		while(first.size()<n)
		{
			int r=random.nextInt(bound);
			if (!first.contains(r)) {
				first.add(score_list.get(r).id);
			}
		}
		// ѵ��Ԥ��
		testAccuracy();
		// �������ݼ�
		update(first);
	}

	public void randomlearning(int n) throws Exception {
		Random random = new Random();
		ArrayList<Integer> list = new ArrayList<>();
		while (list.size() < n) {
			int ran = random.nextInt(unlabel.numInstances());
			if (!list.contains(ran)) {
				list.add(ran);
			}
		}
		testAccuracy();
		update(list);
	}
	
	//���������ѡ�������������
	public void randomlearning(int n,int times) throws Exception {
		Random random = new Random();
		ArrayList<ArrayList<Integer>> group=new ArrayList<>();
		for(int i=0;i<times;i++)
		{
			ArrayList<Integer> list = new ArrayList<>();
			while (list.size() < n) {
				int ran = random.nextInt(unlabel.numInstances());
				if (!list.contains(ran)) {
					list.add(ran);
				}
			}
			group.add(list);
		}
		double max_dis=0;
		ArrayList<Integer> max_list=new ArrayList<>();
		for(ArrayList<Integer> list : group)
		{
			double t=all_dis(list);
			if (t>max_dis) {
				max_list=list;
				max_dis=t;
			}
		}
		testAccuracy();
		update(max_list);
	}
	//������������ṹ�ľ���
	public double all_dis(ArrayList<Integer> list){
		double distance=0;
		for(int i=0;i<list.size();i++)
			for (int j = i+1; j < list.size(); j++) {
				distance+=Neighbourhood.CalDistance(unlabel.instance(i), unlabel.instance(j));
			}
		return distance;
	}
	
	// ����ѵ�������ޱ�ǩ����
	public void update(ArrayList<Integer> list) throws Exception {
		for (int i = 0; i < list.size(); i++) {
			train.add(org_unlabel.instance(list.get(i)));
		}
		Instances new_org_unlabel = new Instances(org_unlabel);
		new_org_unlabel.delete();
		for (int i = 0; i < org_unlabel.numInstances(); i++) {
			if (!list.contains(i)) {
				new_org_unlabel.add(org_unlabel.instance(i));
			}
		}
		org_unlabel = new_org_unlabel;
		unlabel = Util.deleteClass(org_unlabel);
	}

	// ���Ե�ǰ������ȷ��
	public void testAccuracy() throws Exception {
		train.setClassIndex(train.numAttributes() - 1);
		test.setClassIndex(train.numAttributes() - 1);
		Classifier classifier = new J48();
		classifier.buildClassifier(train);
		Evaluation eval = new Evaluation(train);
		eval.evaluateModel(classifier, test);
//		res.add((1 - eval.errorRate()) + "," + eval.areaUnderROC(1));
		res.add((1 - eval.errorRate())+"");
	}

	// �����ޱ�ǩ������ѵ�����е���Ϣ
	public static ArrayList<Double> getInfo_l(Instances train, Instances unlabel, double w) throws Exception {
		ArrayList<Double> list = new ArrayList<>();
		for (int i = 0; i < unlabel.numInstances(); i++) {
			Info_Label info_Label = new Info_Label(train, unlabel.instance(i));
			list.add(info_Label.info_label(w));
		}
		return list;
	}
	//��Ч���ݼ� ionosphere,unbalanced,segment-challenge,trainIJ,trainMN
	public static void main(String[] args) throws Exception {
		String in = "E:\\Program Files\\Weka-3-7\\data\\trainCL.arff";
		//String in ="D:\\Program Files\\Weka-3-8\\data\\airline.arff";
		Instances data = Util.getInstances(in);
		// System.out.println(data.numInstances());
		Active2 active = new Active2(data, 0.005, 0.7);
		for (int i = 0; i < 50; i++) {
			try {
				active.activelearning(2, 100, 0.5, 0.5);
//				active.randomlearning(2);
				
			} catch (Exception e) {
//				e.printStackTrace();
				for (String s : res) {
					System.out.println(s);
				}
			}
			// active.randomlearning(2);
		}
		for (String s : res) {
			System.out.println(s);
		}
	}
}
