package util;

import java.io.BufferedReader;
import java.io.PrintWriter;
import java.util.HashMap;

//Ĭ�ϵ�һ��Ϊ������   ����д���last����first
public class Csv2LibsvmTool {
	public static void transform(String in, String out, String ClassIndex) throws Exception {
		BufferedReader br = Util.readFile(in);
		PrintWriter pt = Util.writeFile(out);
		String f_name[] = br.readLine().split(",");
		for(int i=0;i<f_name.length;i++)
		{
			f_name[i]=i+"";
		}
		HashMap<String, Integer> map=new HashMap<>();
		String line = "";
		int count=0;
		while((line=br.readLine())!=null)
		{
			String label=line.split(",")[ClassIndex.equals("last") ? (f_name.length - 1) : 0];
			if (!map.containsKey(label)) {
				map.put(label, count++);
			}
		}
		br.close();
		br = Util.readFile(in);
		br.readLine();
		int classIndex = ClassIndex.equals("last") ? (f_name.length - 1) : 0;
		if (classIndex == 0) {
			while ((line = br.readLine()) != null) {
				System.out.println(line);
				String t[] = line.split(",");
				StringBuffer sb = new StringBuffer(map.get(t[classIndex])+"");
				for (int i = 1; i < t.length; i++) {
					sb.append("," + f_name[i].replace(".", "_") + ":" + t[i]);
				}
				pt.println(sb.toString());
			}
		} else {
			while ((line = br.readLine()) != null) {
				String t[] = line.split(",");
				StringBuffer sb = new StringBuffer(map.get(t[classIndex])+"");
				for (int i = 0; i < classIndex; i++) {
					sb.append("," + f_name[i].replace(".", "_") + ":" + t[i]);
				}
				pt.println(sb.toString());
			}
		}
		br.close();
		pt.close();
	}
	public static void main(String[] args)throws Exception {
		String in="G:\\�о�\\data\\madelon_1.csv";
		String out="G:\\�о�\\data\\madelon_1.libsvm";
		transform(in, out, "last");
	}
}
